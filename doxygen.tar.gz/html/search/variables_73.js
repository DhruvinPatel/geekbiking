var searchData=
[
  ['shininess',['shininess',['../struct__GLMmaterial.html#a42623b39a8c3a06131750bca1cd83347',1,'_GLMmaterial']]],
  ['specular',['specular',['../struct__GLMmaterial.html#a8a7847baa3892039f974d5bf4aa993be',1,'_GLMmaterial']]]
];
