var searchData=
[
  ['texcoords',['texcoords',['../struct__GLMmodel.html#ab8634a9fd02c2b5f6a8b2d4e77823f65',1,'_GLMmodel']]],
  ['texture_5ffile',['texture_file',['../struct__GLMmodel.html#ada5bc80fb8cbbd0ddee02f6e980f9305',1,'_GLMmodel']]],
  ['tindices',['tindices',['../struct__GLMtriangle.html#a659836cad97a9458493f90117dc8edaa',1,'_GLMtriangle']]],
  ['triangles',['triangles',['../struct__GLMgroup.html#a08193e7d23bf6d32159d659380257240',1,'_GLMgroup::triangles()'],['../struct__GLMmodel.html#adf36c3b98e1f72f828bb5a2a1675272e',1,'_GLMmodel::triangles()']]]
];
