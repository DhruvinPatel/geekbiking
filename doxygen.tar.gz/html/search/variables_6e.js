var searchData=
[
  ['name',['name',['../struct__GLMmaterial.html#a5aabee911354d036897d176132348601',1,'_GLMmaterial::name()'],['../struct__GLMgroup.html#a17de10f71e980597335b72790acd6ec1',1,'_GLMgroup::name()']]],
  ['next',['next',['../struct__GLMgroup.html#a36bec6ef13eb38672c7bcd6d79681945',1,'_GLMgroup']]],
  ['nindices',['nindices',['../struct__GLMtriangle.html#a435600028fff20ba36c044a187b78649',1,'_GLMtriangle']]],
  ['normals',['normals',['../struct__GLMmodel.html#aca8d6dea87a04f72b55ad5ddffbd4102',1,'_GLMmodel']]],
  ['numfacetnorms',['numfacetnorms',['../struct__GLMmodel.html#a087b8336cb092076d6b259a5be9a17a7',1,'_GLMmodel']]],
  ['numgroups',['numgroups',['../struct__GLMmodel.html#a54e1b2ca7e03175c3189a2f5db7f53de',1,'_GLMmodel']]],
  ['nummaterials',['nummaterials',['../struct__GLMmodel.html#a5d84bb75098edd15507bc1f29a5540a9',1,'_GLMmodel']]],
  ['numnormals',['numnormals',['../struct__GLMmodel.html#ab6ab634af259da990dd343da8bb97d60',1,'_GLMmodel']]],
  ['numpolygons',['numpolygons',['../struct__GLMmodel.html#adf1981f905ece944bc6b87c851726f84',1,'_GLMmodel']]],
  ['numtexcoords',['numtexcoords',['../struct__GLMmodel.html#ab53fcb80ed1c4ec402c1254bed586772',1,'_GLMmodel']]],
  ['numtriangles',['numtriangles',['../struct__GLMgroup.html#a7f5703d566fc731318d07d6a82a467f6',1,'_GLMgroup::numtriangles()'],['../struct__GLMmodel.html#a16072026f654ae83cb2de85c39416eef',1,'_GLMmodel::numtriangles()']]],
  ['numvertices',['numvertices',['../struct__GLMmodel.html#ad74d64597f256d85581f1c76a1e82243',1,'_GLMmodel']]]
];
