var searchData=
[
  ['ambient',['ambient',['../struct__GLMmaterial.html#a5009f171fe38cc6da03b637efa1fb116',1,'_GLMmaterial']]]
];
