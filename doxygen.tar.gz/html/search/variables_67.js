var searchData=
[
  ['groups',['groups',['../struct__GLMmodel.html#ad7401a2f601a5720fc560bd49111436c',1,'_GLMmodel']]]
];
