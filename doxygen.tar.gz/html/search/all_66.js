var searchData=
[
  ['facetnorms',['facetnorms',['../struct__GLMmodel.html#ad3b2510d3e3c46ac90bb1c84c16626a9',1,'_GLMmodel']]],
  ['findex',['findex',['../struct__GLMtriangle.html#a5b153daf9e5ffee033dbd919c1a8c02a',1,'_GLMtriangle']]]
];
