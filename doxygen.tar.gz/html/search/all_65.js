var searchData=
[
  ['emmissive',['emmissive',['../struct__GLMmaterial.html#af105c3b731c0f2fe8230d6667455e18b',1,'_GLMmaterial']]]
];
