var searchData=
[
  ['diffuse',['diffuse',['../struct__GLMmaterial.html#a4602d91041b40f1f95f426ee5d71fc89',1,'_GLMmaterial']]]
];
