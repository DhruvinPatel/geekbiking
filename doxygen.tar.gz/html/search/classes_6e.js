var searchData=
[
  ['name',['name',['../classname.html',1,'']]],
  ['newgame1',['newgame1',['../classnewgame1.html',1,'']]],
  ['newgame2',['newgame2',['../classnewgame2.html',1,'']]],
  ['newgame3',['newgame3',['../classnewgame3.html',1,'']]],
  ['node',['node',['../classnode.html',1,'']]]
];
