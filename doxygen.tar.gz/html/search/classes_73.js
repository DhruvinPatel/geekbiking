var searchData=
[
  ['sbox',['sbox',['../classsbox.html',1,'']]],
  ['scores',['scores',['../classscores.html',1,'']]]
];
